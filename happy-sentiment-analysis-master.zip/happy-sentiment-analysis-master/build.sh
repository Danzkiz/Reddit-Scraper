docker build -t happy-sentiment-analysis:$1 .
